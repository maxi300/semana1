function mensaje(){
    alert("hola espera un momento, te contactaremos enseguida");
}


function calcular(){
    nombre=prompt("ingresa tu nombre");
    
}